# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 09:28:02 2023

@author: usn14
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager, rc

font_path = "C:/Windows/Fonts/HYKANB.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)

df = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\weekly_project\\품목별 국가별  수출입실적_시스템(19-23).xlsx')

df = df.iloc[5:]
df = df.rename(columns={'품목별 국가별  수출입실적': '기간', 'Unnamed: 1': '품목명', 'Unnamed: 2': '품목코드', 'Unnamed: 3': '국가명', 'Unnamed: 4': '수출중량', 'Unnamed: 5': '수입중량', 'Unnamed: 6': '수출금액', 'Unnamed: 7': '수입금액', 'Unnamed: 8': '무역수지'})

df['기간'] = df['기간'].astype(str)
df['품목코드'] = df['품목코드'].astype(str)
df['수출중량'] = df['수출중량'].astype(str)
df['수입중량'] = df['수입중량'].astype(str)
df['수출금액'] = df['수출금액'].astype(str)
df['수입금액'] = df['수입금액'].astype(str)
df['무역수지'] = df['무역수지'].astype(str)

df['기간'] = df['기간'].str.replace(',', '').astype(np.int64)
df['품목코드'] = df['품목코드'].str.replace(',', '').astype(np.int64)
df['수출중량'] = df['수출중량'].str.replace(',', '').astype(float)
df['수입중량'] = df['수입중량'].str.replace(',', '').astype(float)
df['수출금액'] = df['수출금액'].str.replace(',', '').astype(np.int64)
df['수입금액'] = df['수입금액'].str.replace(',', '').astype(np.int64)
df['무역수지'] = df['무역수지'].str.replace(',', '').astype(np.int64)

country_system_export_totals_2019_2023 = df.groupby('국가명')['수출금액'].sum().reset_index()
sorted_country_system_export_totals_2019_2023 = country_system_export_totals_2019_2023.sort_values(by='수출금액', ascending=False)
top_5_countries_system_export_totals_2019_2023 = sorted_country_system_export_totals_2019_2023['국가명'].head(5)
top_5_countries_system_export_totals_2019_2023

china_system_2019_2023 = df[df['국가명'] == '중국']
total_system_export_value_china_2019_2023 = china_system_2019_2023['수출금액'].sum()

vietnam_system_2019_2023 = df[df['국가명'] == '베트남']
total_system_export_value_vietnam_2019_2023 = vietnam_system_2019_2023['수출금액'].sum()

singaporu_system_2019_2023 = df[df['국가명'] == '싱가포르']
total_system_export_value_singaporu_2019_2023 = singaporu_system_2019_2023['수출금액'].sum()

taiwan_system_2019_2023 = df[df['국가명'] == '대만']
total_system_export_value_taiwan_2019_2023 = taiwan_system_2019_2023['수출금액'].sum()

hongkong_system_2019_2023 = df[df['국가명'] == '홍콩']
total_system_export_value_hongkong_2019_2023 = hongkong_system_2019_2023['수출금액'].sum()

other_countries_system_export_2019_2023 = sorted_country_system_export_totals_2019_2023[~sorted_country_system_export_totals_2019_2023['국가명'].isin(top_5_countries_system_export_totals_2019_2023)]
other_countries_system_export_total_2019_2023 = other_countries_system_export_2019_2023['수출금액'].sum()

total_system_export_value_2019_2023 = [total_system_export_value_china_2019_2023, total_system_export_value_vietnam_2019_2023, total_system_export_value_singaporu_2019_2023, total_system_export_value_taiwan_2019_2023, total_system_export_value_hongkong_2019_2023, other_countries_system_export_total_2019_2023]




# 각 영역의 범례
labels = ['중국', '베트남', '싱가포르', '대만', '홍콩', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_system_export_value_2019_2023_in_billion = [value / 10000 for value in total_system_export_value_2019_2023]
plt.pie(total_system_export_value_2019_2023, autopct=lambda p: '{:.1f}%\n({})'.format(p, int(sum(total_system_export_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 국가별 반도체 시스템 수출액\n(단위 : 억달러)')

plt.show()


country_system_import_totals_2019_2023 = df.groupby('국가명')['수입금액'].sum().reset_index()
sorted_country_system_import_totals_2019_2023 = country_system_import_totals_2019_2023.sort_values(by='수입금액', ascending=False)
top_5_countries_system_import_totals_2019_2023 = sorted_country_system_import_totals_2019_2023['국가명'].head(5)
top_5_countries_system_import_totals_2019_2023


taiwan_system_2019_2023 = df[df['국가명'] == '대만']
total_system_import_value_taiwan_2019_2023 = taiwan_system_2019_2023['수입금액'].sum()

japan_system_2019_2023 = df[df['국가명'] == '일본']
total_system_import_value_japan_2019_2023 = japan_system_2019_2023['수입금액'].sum()

usa_system_2019_2023 = df[df['국가명'] == '미국']
total_system_import_value_usa_2019_2023 = usa_system_2019_2023['수입금액'].sum()

china_system_2019_2023 = df[df['국가명'] == '중국']
total_system_import_value_china_2019_2023 = china_system_2019_2023['수입금액'].sum()

singaporu_system_2019_2023 = df[df['국가명'] == '싱가포르']
total_system_import_value_singaporu_2019_2023 = singaporu_system_2019_2023['수입금액'].sum()


other_countries_system_import_2019_2023 = sorted_country_system_import_totals_2019_2023[~sorted_country_system_import_totals_2019_2023['국가명'].isin(top_5_countries_system_import_totals_2019_2023)]
other_countries_system_import_total_2019_2023 = other_countries_system_import_2019_2023['수입금액'].sum()

total_system_import_value_2019_2023 = [total_system_import_value_taiwan_2019_2023, total_system_import_value_japan_2019_2023, total_system_import_value_usa_2019_2023, total_system_import_value_china_2019_2023, total_system_import_value_singaporu_2019_2023, other_countries_system_import_total_2019_2023]


# 각 영역의 범례
labels = ['대만', '일본', '미국', '중국', '싱가포르', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_system_import_value_2019_2023_in_billion = [value / 10000 for value in total_system_import_value_2019_2023]
plt.pie(total_system_import_value_2019_2023_in_billion, autopct=lambda p: '{:.1f}%\n({})'.format(p, int(sum(total_system_import_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 국가별 반도체 시스템 수입액\n(단위 : 억달러)')

plt.show()



item_system_export_totals_2019_2023 = df.groupby('품목명')['수출금액'].sum().reset_index()
sorted_item_system_export_totals_2019_2023 = item_system_export_totals_2019_2023.sort_values(by='수출금액', ascending=False)
top_5_item_system_export_totals_2019_2023 = sorted_item_system_export_totals_2019_2023['품목명'].head(5)
top_5_item_system_export_totals_2019_2023

monolithic_2019_2023 = df[df['품목명'] == '모노리식(monolithic) 집적회로']
total_export_value_monolithic_2019_2023 = monolithic_2019_2023['수출금액'].sum()

composite_chip_2019_2023 = df[df['품목명'] == '복합구조칩 집적회로']
total_export_composite_2019_2023 = composite_chip_2019_2023['수출금액'].sum()

machine_8517_2019_2023 = df[df['품목명'] == '제8517호의 기기에 전용되거나 주로 사용되는 것']
total_export_value_machine_8517_2019_2023 = machine_8517_2019_2023['수출금액'].sum()

mcos_2019_2023 = df[df['품목명'] == '복합부품 집적회로(MCOs)']
total_export_value_mcos_2019_2023 = mcos_2019_2023['수출금액'].sum()

rest_2019_2023 = df[df['품목명'] == '기타']
total_export_value_rest_2019_2023 = rest_2019_2023['수출금액'].sum()


other_item_system_export_name_2019_2023 = sorted_item_system_export_totals_2019_2023[~sorted_item_system_export_totals_2019_2023['품목명'].isin(top_5_item_system_export_totals_2019_2023)]
other_item_system_export_totals_2019_2023 = other_item_system_export_name_2019_2023['수출금액'].sum()


total_item_system_export_value_2019_2023 = [total_export_value_monolithic_2019_2023, total_export_composite_2019_2023, total_export_value_machine_8517_2019_2023, total_export_value_mcos_2019_2023, total_export_value_rest_2019_2023, other_item_system_export_totals_2019_2023]


# 각 영역의 범례
labels = ['모노리식 직접회로', '복합구조칩 집적회로', '제8517호', 'MCOs', '기타', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_item_system_export_value_2019_2023_in_billion = [value / 10000 for value in total_item_system_export_value_2019_2023]
plt.pie(total_item_system_export_value_2019_2023, autopct=lambda p: '{:.1f}%({})'.format(p, int(sum(total_item_system_export_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 품목별 반도체 시스템 수출액\n(단위 : 억달러)')

plt.show()


item_system_import_totals_2019_2023 = df.groupby('품목명')['수입금액'].sum().reset_index()
sorted_item_system_import_totals_2019_2023 = item_system_import_totals_2019_2023.sort_values(by='수입금액', ascending=False)
top_5_item_system_import_totals_2019_2023 = sorted_item_system_import_totals_2019_2023['품목명'].head(5)
top_5_item_system_import_totals_2019_2023


monolithic_2019_2023 = df[df['품목명'] == '모노리식(monolithic) 집적회로']
total_import_value_monolithic_2019_2023 = monolithic_2019_2023['수입금액'].sum()

machine_8517_2019_2023 = df[df['품목명'] == '제8517호의 기기에 전용되거나 주로 사용되는 것']
total_import_value_machine_8517_2019_2023 = machine_8517_2019_2023['수입금액'].sum()

mcos_2019_2023 = df[df['품목명'] == '복합부품 집적회로(MCOs)']
total_import_value_mcos_2019_2023 = mcos_2019_2023['수입금액'].sum()

composite_chip_2019_2023 = df[df['품목명'] == '복합구조칩 집적회로']
total_import_composite_2019_2023 = composite_chip_2019_2023['수입금액'].sum()

machine_8425_2019_2023 = df[df['품목명'] == '제8425호ㆍ제8426호ㆍ제8428호ㆍ제8429호ㆍ제8430호ㆍ제8443.99호ㆍ8470호ㆍ제8471호ㆍ제8472호ㆍ제9026호ㆍ제9030호ㆍ제9504호의 기계 또는 기기에 전용되거나 주로 사용되는 것']
total_import_value_machine_8425_2019_2023 = machine_8425_2019_2023['수입금액'].sum()


other_item_system_import_name_2019_2023 = sorted_item_system_import_totals_2019_2023[~sorted_item_system_import_totals_2019_2023['품목명'].isin(top_5_item_system_import_totals_2019_2023)]
other_item_system_import_totals_2019_2023 = other_item_system_import_name_2019_2023['수입금액'].sum()


total_item_system_import_value_2019_2023 = [total_import_value_monolithic_2019_2023, total_import_value_machine_8517_2019_2023, total_import_value_mcos_2019_2023, total_import_composite_2019_2023, total_import_value_machine_8425_2019_2023, other_item_system_import_totals_2019_2023]


# 각 영역의 범례
labels = ['모노리식 직접회로', '제8517호', 'MCOs', '복합구조칩 집적회로', '제8425호', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_item_system_import_value_2019_2023_in_billion = [value / 10000 for value in total_item_system_import_value_2019_2023]
plt.pie(total_item_system_import_value_2019_2023, autopct=lambda p: '{:.1f}%({})'.format(p, int(sum(total_item_system_import_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 품목별 반도체 시스템 수입액\n(단위 : 억달러)')

plt.show()



df2 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\weekly_project\\품목별 국가별  수출입실적_메모리(19-23).xlsx')
df2 = df2.iloc[5:]
df2 = df2.rename(columns={'품목별 국가별  수출입실적': '기간', 'Unnamed: 1': '품목명', 'Unnamed: 2': '품목코드', 'Unnamed: 3': '국가명', 'Unnamed: 4': '수출중량', 'Unnamed: 5': '수입중량', 'Unnamed: 6': '수출금액', 'Unnamed: 7': '수입금액', 'Unnamed: 8': '무역수지'})

df2['기간'] = df2['기간'].astype(str)
df2['품목코드'] = df2['품목코드'].astype(str)
df2['수출중량'] = df2['수출중량'].astype(str)
df2['수입중량'] = df2['수입중량'].astype(str)
df2['수출금액'] = df2['수출금액'].astype(str)
df2['수입금액'] = df2['수입금액'].astype(str)
df2['무역수지'] = df2['무역수지'].astype(str)

df2['기간'] = df2['기간'].str.replace(',', '').astype(np.int64)
df2['품목코드'] = df2['품목코드'].str.replace(',', '').astype(np.int64)
df2['수출중량'] = df2['수출중량'].str.replace(',', '').astype(float)
df2['수입중량'] = df2['수입중량'].str.replace(',', '').astype(float)
df2['수출금액'] = df2['수출금액'].str.replace(',', '').astype(np.int64)
df2['수입금액'] = df2['수입금액'].str.replace(',', '').astype(np.int64)
df2['무역수지'] = df2['무역수지'].str.replace(',', '').astype(np.int64)



memory_export_totals_2019_2023 = df2.groupby('국가명')['수출금액'].sum().reset_index()
sorted_memory_export_totals_2019_2023 = memory_export_totals_2019_2023.sort_values(by='수출금액', ascending=False)
top_5_countries_memory_export_totals_2019_2023 = sorted_memory_export_totals_2019_2023['국가명'].head(5)
top_5_countries_memory_export_totals_2019_2023

china_memory_2019_2023 = df2[df2['국가명'] == '중국']
total_memory_export_value_china_2019_2023 = china_memory_2019_2023['수출금액'].sum()

hongkong_memory_2019_2023 = df2[df2['국가명'] == '홍콩']
total_memory_export_value_hongkong_2019_2023 = hongkong_memory_2019_2023['수출금액'].sum()

vietnam_memory_2019_2023 = df2[df2['국가명'] == '베트남']
total_memory_export_value_vietnam_2019_2023 = vietnam_memory_2019_2023['수출금액'].sum()

taiwan_memory_2019_2023 = df2[df2['국가명'] == '대만']
total_memory_export_value_taiwan_2019_2023 = taiwan_memory_2019_2023['수출금액'].sum()

philippines_memory_2019_2023 = df2[df2['국가명'] == '필리핀']
total_memory_export_value_philippines_2019_2023 = philippines_memory_2019_2023['수출금액'].sum()


other_countries_memory_export_2019_2023 = sorted_memory_export_totals_2019_2023[~sorted_memory_export_totals_2019_2023['국가명'].isin(top_5_countries_memory_export_totals_2019_2023)]
other_memory_export_total_2019_2023 = other_countries_memory_export_2019_2023['수출금액'].sum()

total_memory_export_value_2019_2023 = [total_memory_export_value_china_2019_2023, total_memory_export_value_hongkong_2019_2023, total_memory_export_value_vietnam_2019_2023, total_memory_export_value_taiwan_2019_2023, total_memory_export_value_philippines_2019_2023, other_memory_export_total_2019_2023]

# 각 영역의 범례
labels = ['중국', '홍콩', '베트남', '대만', '필리핀', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_memory_export_value_2019_2023_in_billion = [value / 10000 for value in total_memory_export_value_2019_2023]
plt.pie(total_memory_export_value_2019_2023_in_billion, autopct=lambda p: '{:.1f}%\n({})'.format(p, int(sum(total_memory_export_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 국가별 반도체 메모리 수출액\n(단위 : 억달러)')

plt.show()





memory_import_totals_2019_2023 = df2.groupby('국가명')['수입금액'].sum().reset_index()
sorted_memory_import_totals_2019_2023 = memory_import_totals_2019_2023.sort_values(by='수입금액', ascending=False)
top_5_countries_memory_import_totals_2019_2023 = sorted_memory_import_totals_2019_2023['국가명'].head(5)
top_5_countries_memory_import_totals_2019_2023

china_memory_2019_2023 = df2[df2['국가명'] == '중국']
total_memory_import_value_china_2019_2023 = china_memory_2019_2023['수입금액'].sum()

taiwan_memory_2019_2023 = df2[df2['국가명'] == '대만']
total_memory_import_value_taiwan_2019_2023 = taiwan_memory_2019_2023['수입금액'].sum()

restcountry_memory_2019_2023 = df2[df2['국가명'] == '기타국']
total_memory_import_value_restcountry_2019_2023 = restcountry_memory_2019_2023['수입금액'].sum()

hongkong_memory_2019_2023 = df2[df2['국가명'] == '홍콩']
total_memory_import_value_hongkong_2019_2023 = hongkong_memory_2019_2023['수입금액'].sum()

singaporu_memory_2019_2023 = df2[df2['국가명'] == '싱가포르']
total_memory_import_value_singaporu_2019_2023 = singaporu_memory_2019_2023['수입금액'].sum()


other_countries_memory_import_2019_2023 = sorted_memory_import_totals_2019_2023[~sorted_memory_import_totals_2019_2023['국가명'].isin(top_5_countries_memory_import_totals_2019_2023)]
other_memory_import_total_2019_2023 = other_countries_memory_import_2019_2023['수입금액'].sum()


total_memory_import_value_2019_2023 = [total_memory_import_value_china_2019_2023, total_memory_import_value_taiwan_2019_2023, total_memory_import_value_restcountry_2019_2023, total_memory_import_value_hongkong_2019_2023, total_memory_import_value_singaporu_2019_2023, other_memory_import_total_2019_2023]


# 각 영역의 범례
labels = ['중국', '대만', '기타국', '홍콩', '싱가포르', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_memory_import_value_2019_2023_in_billion = [value / 10000 for value in total_memory_import_value_2019_2023]
plt.pie(total_memory_import_value_2019_2023_in_billion, autopct=lambda p: '{:.1f}%({})'.format(p, int(sum(total_memory_import_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 국가별 반도체 메모리 수입액\n(단위 : 억달러)')

plt.show()


item_memory_export_totals_2019_2023 = df2.groupby('품목명')['수출금액'].sum().reset_index()
sorted_item_memory_export_totals_2019_2023 = item_memory_export_totals_2019_2023.sort_values(by='수출금액', ascending=False)
top_5_item_memory_export_totals_2019_2023 = sorted_item_memory_export_totals_2019_2023['품목명'].head(5)
top_5_item_memory_export_totals_2019_2023

composite_chip_memory_2019_2023 = df2[df2['품목명'] == '복합구조칩 집적회로']
total_export_value_composite_memory_2019_2023 = composite_chip_memory_2019_2023['수출금액'].sum()

dram_memory_2019_2023 = df2[df2['품목명'] == '디램']
total_export_value_dram_memory_2019_2023 = dram_memory_2019_2023['수출금액'].sum()

flash_memory_2019_2023 = df2[df2['품목명'] == '플래시 메모리']
total_export_value_flash_memory_2019_2023 = flash_memory_2019_2023['수출금액'].sum()

machine_8517_memory_2019_2023 = df2[df2['품목명'] == '제8517호의 기기에 전용되거나 주로 사용되는 것']
total_export_value_machine_8517_memory = machine_8517_memory_2019_2023['수출금액'].sum()

mcos_memory_2019_2023 = df2[df2['품목명'] == '복합부품 집적회로(MCOs)']
total_export_value_mcos_memory_2019_2023 = mcos_memory_2019_2023['수출금액'].sum()

other_item_memory_export_name_2019_2023 = sorted_item_memory_export_totals_2019_2023[~sorted_item_memory_export_totals_2019_2023['품목명'].isin(top_5_item_memory_export_totals_2019_2023)]
other_item_memory_export_totals_2019_2023 = other_item_memory_export_name_2019_2023['수출금액'].sum()

total_item_memory_export_value_2019_2023 = [total_export_value_composite_memory_2019_2023, total_export_value_dram_memory_2019_2023, total_export_value_flash_memory_2019_2023, total_export_value_machine_8517_memory, total_export_value_mcos_memory_2019_2023, other_item_memory_export_totals_2019_2023]


# 각 영역의 범례
labels = ['복합구조칩 집적회로', '디램', '플래시 메모리', '제8517호', 'MCOs', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_item_memory_export_value_2019_2023_in_billion = [value / 10000 for value in total_item_memory_export_value_2019_2023]
plt.pie(total_item_memory_export_value_2019_2023, autopct=lambda p: '{:.1f}%({})'.format(p, int(sum(total_item_memory_export_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 품목별 반도체 메모리 수출액\n(단위 : 억달러)')

plt.show()


item_memory_import_totals_2019_2023 = df2.groupby('품목명')['수입금액'].sum().reset_index()
sorted_item_memory_import_totals_2019_2023 = item_memory_import_totals_2019_2023.sort_values(by='수입금액', ascending=False)
top_5_item_memory_import_totals_2019_2023 = sorted_item_memory_import_totals_2019_2023['품목명'].head(5)
top_5_item_memory_import_totals_2019_2023


composite_chip_memory_2019_2023 = df2[df2['품목명'] == '복합구조칩 집적회로']
total_import_value_composite_memory_2019_2023 = composite_chip_memory_2019_2023['수입금액'].sum()

dram_memory_2019_2023 = df2[df2['품목명'] == '디램']
total_import_value_dram_memory_2019_2023 = dram_memory_2019_2023['수입금액'].sum()

flash_memory_2019_2023 = df2[df2['품목명'] == '플래시 메모리']
total_import_value_flash_memory_2019_2023 = flash_memory_2019_2023['수입금액'].sum()

machine_8517_memory_2019_2023 = df2[df2['품목명'] == '제8517호의 기기에 전용되거나 주로 사용되는 것']
total_import_value_machine_8517_memory = machine_8517_memory_2019_2023['수입금액'].sum()

mcos_memory_2019_2023 = df2[df2['품목명'] == '복합부품 집적회로(MCOs)']
total_import_value_mcos_memory_2019_2023 = mcos_memory_2019_2023['수입금액'].sum()

other_item_memory_import_name_2019_2023 = sorted_item_memory_import_totals_2019_2023[~sorted_item_memory_import_totals_2019_2023['품목명'].isin(top_5_item_memory_import_totals_2019_2023)]
other_item_memory_import_totals_2019_2023 = other_item_memory_import_name_2019_2023['수입금액'].sum()

total_item_memory_import_value_2019_2023 = [total_import_value_composite_memory_2019_2023, total_import_value_dram_memory_2019_2023, total_import_value_flash_memory_2019_2023, total_import_value_machine_8517_memory, total_import_value_mcos_memory_2019_2023, other_item_memory_import_totals_2019_2023]


# 각 영역의 범례
labels = ['복합구조칩 집적회로', '디램', '플래시 메모리', '제8517호', 'MCOs', '기타']

# 각 영역이 중심으로부터 떨어진 거리
explode = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

# 각 영역의 색상
colors = ['lightpink', 'lightyellow', 'lightgreen', 'lightskyblue', 'lightcoral', 'lightgray']
# 천불을 억불로 변환
total_item_memory_import_value_2019_2023_in_billion = [value / 10000 for value in total_item_memory_import_value_2019_2023]
plt.pie(total_item_memory_import_value_2019_2023, autopct=lambda p: '{:.1f}%({})'.format(p, int(sum(total_item_memory_import_value_2019_2023_in_billion) * p / 100)), labels=labels, explode=explode, colors=colors, shadow=True)

plt.title('2019~2023년 품목별 반도체 메모리 수입액\n(단위 : 억달러)')

plt.show()