# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 14:26:34 2023

@author: usn14
"""

import streamlit as st
from page import page as pg

st.title('주간 프로젝트 (2조)')



item = st.sidebar.selectbox('항목을 골라요', ['처리 및 분석한 내용'])


if item == '처리 및 분석한 내용':
    pg.app()