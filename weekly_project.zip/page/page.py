# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 13:55:30 2023

@author: usn14
"""


from utils import module as mo
import streamlit as st

def app():    
    
    
    total_system_export_value_2019_2023 = mo.get_data_country_system_export_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_시스템(19-23).xlsx')
    total_system_import_value_2019_2023 = mo.get_data_country_system_import_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_시스템(19-23).xlsx')
    total_item_system_export_value_2019_2023 = mo.get_data_item_system_export_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_시스템(19-23).xlsx')
    total_item_system_import_value_2019_2023 = mo.get_data_item_system_import_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_시스템(19-23).xlsx')
    total_memory_export_value_2019_2023 = mo.get_data_country_memory_export_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_메모리(19-23).xlsx')
    total_memory_import_value_2019_2023 = mo.get_data_country_memory_import_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_메모리(19-23).xlsx')
    total_item_memory_export_value_2019_2023 = mo.get_data_item_memory_export_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_메모리(19-23).xlsx')
    total_item_memory_import_value_2019_2023 = mo.get_data_item_memory_import_totals_2019_2023('C:/Users/usn14/.spyder-py3/python_basic/weekly_project/품목별 국가별  수출입실적_메모리(19-23).xlsx')



    st.write('2019~2023년 국가별 반도체 시스템 수출액')
    data = {'2019~2023년 국가별 반도체 시스템 수출액': total_system_export_value_2019_2023}
    total_system_export_value_2019_2023_graph = mo.total_system_export_value_2019_2023_graph(data, '2019~2023년 국가별 반도체 시스템 수출액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_system_export_value_2019_2023_graph)
    
    
    
    st.write('2019~2023년 국가별 반도체 시스템 수입액')
    data = {'2019~2023년 국가별 반도체 시스템 수입액': total_system_import_value_2019_2023}
    total_system_import_value_2019_2023_graph = mo.total_system_import_value_2019_2023_graph(data, '2019~2023년 국가별 반도체 시스템 수입액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_system_import_value_2019_2023_graph)
    
    
    
    st.write('2019~2023년 품목별 반도체 시스템 수출액')
    data = {'2019~2023년 품목별 반도체 시스템 수출액': total_item_system_export_value_2019_2023}
    total_item_system_export_value_2019_2023_graph = mo.total_item_system_export_value_2019_2023_graph(data, '2019~2023년 품목별 반도체 시스템 수출액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_item_system_export_value_2019_2023_graph)
    
    
    st.write('2019~2023년 품목별 반도체 시스템 수입액')
    data = {'2019~2023년 품목별 반도체 시스템 수입액': total_item_system_import_value_2019_2023}
    total_item_system_import_value_2019_2023_graph = mo.total_item_system_import_value_2019_2023_graph(data, '2019~2023년 품목별 반도체 시스템 수입액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_item_system_import_value_2019_2023_graph)
    
    
    
    st.write('2019~2023년 국가별 반도체 메모리 수출액')
    data = {'2019~2023년 국가별 반도체 메모리 수출액': total_memory_export_value_2019_2023}
    total_memory_export_value_2019_2023_graph = mo.total_memory_export_value_2019_2023_graph(data, '2019~2023년 국가별 반도체 메모리 수출액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_memory_export_value_2019_2023_graph)
    
    
    st.write('2019~2023년 국가별 반도체 메모리 수입액')
    data = {'2019~2023년 국가별 반도체 메모리 수입액': total_memory_import_value_2019_2023}
    total_memory_import_value_2019_2023_graph = mo.total_memory_import_value_2019_2023_graph(data, '2019~2023년 국가별 반도체 메모리 수입액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_memory_import_value_2019_2023_graph)
    
    
    st.write('2019~2023년 품목별 반도체 메모리 수출액')
    data = {'2019~2023년 품목별 반도체 메모리 수출액': total_item_memory_export_value_2019_2023}
    total_item_memory_export_value_2019_2023_graph = mo.total_item_memory_export_value_2019_2023_graph(data, '2019~2023년 품목별 반도체 메모리 수출액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_item_memory_export_value_2019_2023_graph)
    
    
    st.write('2019~2023년 품목별 반도체 메모리 수입액')
    data = {'2019~2023년 품목별 반도체 메모리 수입액': total_item_memory_import_value_2019_2023}
    total_item_memory_import_value_2019_2023_graph = mo.total_item_memory_import_value_2019_2023_graph(data, '2019~2023년 품목별 반도체 메모리 수입액\n(단위 : 억달러)')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(total_item_memory_import_value_2019_2023_graph)
    
    